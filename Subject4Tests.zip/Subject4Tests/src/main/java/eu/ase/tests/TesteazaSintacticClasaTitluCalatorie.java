package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Teste ce corespund punctajului 3
 */

public class TesteazaSintacticClasaTitluCalatorie {

    static Class titluCalatorieClass;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            titluCalatorieClass = setup.loadClassFromProjectPath(projectPath, "eu.ase.TitluCalatorie");
        } catch (Exception e) {
            System.out.println("Could not load TitluCalatorie " + e.getMessage());
        }
    }

    @Test
    public void testeazaTitluCalatorieEsteClasaAbstracta() {
        assertTrue(Modifier.isAbstract(titluCalatorieClass.getModifiers()));
    }


    @Test
    public void testeazaAtributulId() {
        try {
            Field atributId = titluCalatorieClass.getDeclaredField("id");
            assertNotNull(atributId);
            assertTrue("Atributul 'id' este privat",  Modifier.isPrivate(atributId.getModifiers()));
            assertEquals("Atributul 'atributId' este de tip int ", int.class, atributId.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'id' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaAtributulDenumire() {
        try {
            Field atributDenumire = titluCalatorieClass.getDeclaredField("denumire");
            assertNotNull(atributDenumire);
            assertTrue("Atributul 'denumire' este privat",  Modifier.isPrivate(atributDenumire.getModifiers()));
            assertEquals("Atributul 'denumire' este de tip String", String.class, atributDenumire.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'denumire' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaAtributulIdLinie() {
        try {
            Field atributIdLinie = titluCalatorieClass.getDeclaredField("idLinie");
            assertNotNull(atributIdLinie);
            assertTrue("Atributul 'idLinie' este privat",  Modifier.isPrivate(atributIdLinie.getModifiers()));
            assertEquals("Atributul 'idLinie' este de tip float", float.class, atributIdLinie.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'idLinie' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaAtributulDataStart() {
        try {
            Field atributDataStart = titluCalatorieClass.getDeclaredField("dataStart");
            assertNotNull(atributDataStart);
            assertTrue("Atributul 'dataStart' este privat",  Modifier.isPrivate(atributDataStart.getModifiers()));
            assertEquals("Atributul 'dataStart' este de tip String", String.class, atributDataStart.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'dataStart' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaAtributulDataStop() {
        try {
            Field atributDataStop = titluCalatorieClass.getDeclaredField("dataStop");
            assertNotNull(atributDataStop);
            assertTrue("Atributul 'dataStop' este privat",  Modifier.isPrivate(atributDataStop.getModifiers()));
            assertEquals("Atributul 'dataStop' este de tip String", String.class, atributDataStop.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'dataStop' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaAtributulIdZona() {
        try {
            Field atributIdZona = titluCalatorieClass.getDeclaredField("idZona");
            assertNotNull(atributIdZona);
            assertTrue("Atributul 'idZona' este privat",  Modifier.isPrivate(atributIdZona.getModifiers()));
            assertTrue("Atributul 'idZona' este final",  Modifier.isFinal(atributIdZona.getModifiers()));
            assertEquals("Atributul 'idZona' este de tip int", int.class, atributIdZona.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'idZona' nu exista in clasa " + titluCalatorieClass);
        }
    }

    @Test
    public void testeazaConstructorAlClaseiTitluCalatorie() {
        Constructor[] constructori = titluCalatorieClass.getConstructors();
        assertEquals("Exista un singur constructor definit in clasa " + titluCalatorieClass, 1, constructori.length);

        Constructor constructorDeclarat = constructori[0];
        assertEquals("Exista cinci parametri definiti pentru constructorul clasei " + titluCalatorieClass, 5, constructorDeclarat.getParameterCount());

        Class[] tipuriParametri = constructorDeclarat.getParameterTypes();

        int numarParametriString = 0;
        int numarParametriFloat = 0;
        int numarParametriInt = 0;
        for(int i=0; i< tipuriParametri.length; i++) {
            numarParametriString = tipuriParametri[i].equals(String.class) ? numarParametriString + 1 : numarParametriString;
            numarParametriFloat = tipuriParametri[i].equals(float.class) ? numarParametriFloat + 1 : numarParametriFloat;
            numarParametriInt = tipuriParametri[i].equals(int.class) ? numarParametriInt + 1 : numarParametriInt;
        }

        assertEquals("Exista trei parametri String ", 3, numarParametriString);
        assertEquals("Exista un parametru float ", 1, numarParametriFloat);
        assertEquals("Exista doi parametri int ", 1, numarParametriInt);
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulId() {
        try {
            Method metodaAccesId = titluCalatorieClass.getMethod("getId");
            assertTrue("Metoda de acces id este publica", Modifier.isPublic(metodaAccesId.getModifiers()));
            assertEquals("Metoda get id intoarce int", int.class, metodaAccesId.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getId() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulDenumire() {
        try {
            Method metodaAccesDenumire = titluCalatorieClass.getMethod("getDenumire");
            assertTrue("Metoda de acces denumire este publica", Modifier.isPublic(metodaAccesDenumire.getModifiers()));
            assertEquals("Metoda get denumire intoarce String", String.class, metodaAccesDenumire.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getDenumire() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulIdLinie() {
        try {
            Method metodaAccesIdLinie = titluCalatorieClass.getMethod("getIdLinie");
            assertTrue("Metoda de acces idLinie este publica", Modifier.isPublic(metodaAccesIdLinie.getModifiers()));
            assertEquals("Metoda get idLinie intoarce float", float.class, metodaAccesIdLinie.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getIdLinie() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulDataStart() {
        try {
            Method metodaAccesDataStart = titluCalatorieClass.getMethod("getDataStart");
            assertTrue("Metoda de acces dataStart este publica", Modifier.isPublic(metodaAccesDataStart.getModifiers()));
            assertEquals("Metoda get dataStart intoarce String", String.class, metodaAccesDataStart.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getDataStart() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulDataStop() {
        try {
            Method metodaAccesDataStop = titluCalatorieClass.getMethod("getDataStop");
            assertTrue("Metoda de acces dataStop este publica", Modifier.isPublic(metodaAccesDataStop.getModifiers()));
            assertEquals("Metoda get dataStop intoarce String", String.class, metodaAccesDataStop.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getDataStop() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaAbstractaGetIdZona() {
        try {
            Method metodaGetIdZona = titluCalatorieClass.getMethod("getIdZona");
            assertTrue("Metoda getIdZona este publica", Modifier.isPublic(metodaGetIdZona.getModifiers()));
            assertTrue("Metoda getIdZona este abstracta", Modifier.isAbstract(metodaGetIdZona.getModifiers()));
            assertEquals("Metoda getIdZona intoarce String", String.class, metodaGetIdZona.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getIdZona() nu este definita");
        }
    }


}
