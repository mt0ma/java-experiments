package eu.ase.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        TesteazaSintacticClasaTitluCalatorie.class,
        TesteazaTitluCalatorieMetropolitan.class,
        TesteazaTitluCalatorieUrban.class,
        TesteazaMatrice.class
})
/*
 * Suita teste pentru nota 5
 */
public class TestSuite {
}
