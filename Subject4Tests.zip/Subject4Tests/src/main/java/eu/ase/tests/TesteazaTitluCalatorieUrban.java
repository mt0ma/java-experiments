package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;

/**
 * Testeaza TitluCalatorieUrban
 */
public class TesteazaTitluCalatorieUrban {
    static Class titluDeCalatorieUrban;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            titluDeCalatorieUrban = setup.loadClassFromProjectPath(projectPath, "eu.ase.TitluCalatorieUrban");
        } catch (Exception e) {
            System.out.println("Could not load TitluCalatorieUrban " + e.getMessage());
        }
    }

    @Test
    public void testeazaAtributulDenumireOperatorUrban() {
        try {
            Field denumire = titluDeCalatorieUrban.getDeclaredField("denumireOperatorUrban");
            assertNotNull(denumire);
            assertTrue("Atributul 'denumireOperatorUrban' este privat",  Modifier.isPrivate(denumire.getModifiers()));
            assertEquals("Atributul 'denumireOperatorUrban' este de tip String", String.class, denumire.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'denumireOperatorUrban' nu exista in clasa " + titluDeCalatorieUrban);
        }
    }

    @Test
    public void testeazaMetodeDeAccesPentruCampulDenumireOperatorMetropolitan() {
        try {
            Method metodaAccesGetDenumire = titluDeCalatorieUrban.getMethod("getDenumireOperatorUrban");
            Method metodaAccesSetDenumire = titluDeCalatorieUrban.getMethod("setDenumireOperatorUrban", String.class);

            assertTrue("Metoda de acces getDenumireOperatorUrban este publica", Modifier.isPublic(metodaAccesGetDenumire.getModifiers()));
            assertEquals("Metoda get getDenumireOperatorUrban intoarce String", String.class, metodaAccesGetDenumire.getReturnType());

            assertTrue("Metoda de acces setDenumireOperatorUrban este publica", Modifier.isPublic(metodaAccesSetDenumire.getModifiers()));
            assertEquals("Metoda get setDenumireOperatorUrban are un parametru", 1, metodaAccesSetDenumire.getParameterCount());
            assertEquals("Metoda get setDenumireOperatorUrban intoarce void", void.class, metodaAccesSetDenumire.getReturnType());

        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getDenumireOperatorUrban() sau setDenumireOperatorUrban() nu este definita");
        }
    }

    @Test(expected = Exception.class)
    public void testeazaConstructorGenereazaExceptie() throws Exception{
        Object titluCalatorie = titluDeCalatorieUrban.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", -3.0f, "denumire-operator");
    }

    @Test
    public void testeazaGetIdZona() throws Exception {
        Object titluCalatorie = titluDeCalatorieUrban.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");
        Method getIdZona = titluDeCalatorieUrban.getMethod("getIdZona");
        assertEquals("getIdZona() intoarce id linie concatenat cu denumire operator",
                new String(3.0f + "denumire-operator"),
                getIdZona.invoke(titluCalatorie));
    }

    @Test
    public void testeazaEquals() throws Exception{
        Object primul = titluDeCalatorieUrban.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");

        Object acelasi = primul;
        assertTrue("testeaza equals de referinta", primul.equals(acelasi));

        Object unulNull = null;
        assertFalse("testeaza equals de null", primul.equals(unulNull));

        Object altfelDeObiect = new String("denumire");
        assertFalse("testeaza equals de tip", primul.equals(altfelDeObiect));

        Object alDoilea = titluDeCalatorieUrban.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");
        assertTrue("primul equals alDoilea", primul.equals(alDoilea));
    }

    @Test
    public void testeazaClone() {
        try {
            Object primul = titluDeCalatorieUrban.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                    newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");

            Method cloneMethod = titluDeCalatorieUrban.getMethod("clone");

            Object clona = cloneMethod.invoke(primul);

            Method setDenumire = titluDeCalatorieUrban.getMethod("setDenumireOperatorUrban", String.class);
            Method getDenumire = titluDeCalatorieUrban.getMethod("getDenumireOperatorUrban");

            setDenumire.invoke(clona, "test clone");

            assertEquals("testeaza denumire operator primul", "denumire-operator", getDenumire.invoke(primul));
            assertEquals("testeaza denumire operator clona", "test clone", getDenumire.invoke(clona));
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
