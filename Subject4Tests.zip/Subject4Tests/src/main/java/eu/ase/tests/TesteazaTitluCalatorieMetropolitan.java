package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;

/**
 * Testeaza TitluCalatorieMetropolitan
 */
public class TesteazaTitluCalatorieMetropolitan {
    static Class titluDeCalatorieMetropolitan;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            titluDeCalatorieMetropolitan = setup.loadClassFromProjectPath(projectPath, "eu.ase.TitluCalatorieMetropolitan");
        } catch (Exception e) {
            System.out.println("Could not load TitluCalatorieMetropolitan " + e.getMessage());
        }
    }

    @Test
    public void testeazaAtributulDenumireOperatorMetropolitan() {
        try {
            Field denumire = titluDeCalatorieMetropolitan.getDeclaredField("denumireOperatorMetropolitan");
            assertNotNull(denumire);
            assertTrue("Atributul 'denumireOperatorMetropolitan' este privat",  Modifier.isPrivate(denumire.getModifiers()));
            assertEquals("Atributul 'denumireOperatorMetropolitan' este de tip String", String.class, denumire.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'denumireOperatorMetropolitan' nu exista in clasa " + titluDeCalatorieMetropolitan);
        }
    }

    @Test
    public void testeazaMetodeDeAccesPentruCampulDenumireOperatorMetropolitan() {
        try {
            Method metodaAccesGetDenumire = titluDeCalatorieMetropolitan.getMethod("getDenumireOperatorMetropolitan");
            Method metodaAccesSetDenumire = titluDeCalatorieMetropolitan.getMethod("setDenumireOperatorMetropolitan", String.class);

            assertTrue("Metoda de acces getDenumireOperatorMetropolitan este publica", Modifier.isPublic(metodaAccesGetDenumire.getModifiers()));
            assertEquals("Metoda get getDenumireOperatorMetropolitan intoarce String", String.class, metodaAccesGetDenumire.getReturnType());

            assertTrue("Metoda de acces setDenumireOperatorMetropolitan este publica", Modifier.isPublic(metodaAccesSetDenumire.getModifiers()));
            assertEquals("Metoda get setDenumireOperatorMetropolitan are un parametru", 1, metodaAccesSetDenumire.getParameterCount());
            assertEquals("Metoda get setDenumireOperatorMetropolitan intoarce void", void.class, metodaAccesSetDenumire.getReturnType());

        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getDenumireOperatorMetropolitan() sau setDenumireOperatorMetropolitan() nu este definita");
        }
    }

    @Test(expected = Exception.class)
    public void testeazaConstructorGenereazaExceptie() throws Exception{
        Object titluCalatorie = titluDeCalatorieMetropolitan.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", -3.0f, "denumire-operator");
    }

    @Test
    public void testeazaGetIdZona() throws Exception {
        Object titluCalatorie = titluDeCalatorieMetropolitan.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");
        Method getIdZona = titluDeCalatorieMetropolitan.getMethod("getIdZona");
        assertEquals("getIdZona() intoarce id linie concatenat cu denumire operator",
                new String(3.0f + "denumire-operator"),
                getIdZona.invoke(titluCalatorie));
    }

    @Test
    public void testeazaEquals() throws Exception{
        Object primul = titluDeCalatorieMetropolitan.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");

        Object acelasi = primul;
        assertTrue("testeaza equals de referinta", primul.equals(acelasi));

        Object unulNull = null;
        assertFalse("testeaza equals de null", primul.equals(unulNull));

        Object altfelDeObiect = new String("denumire");
        assertFalse("testeaza equals de tip", primul.equals(altfelDeObiect));

        Object alDoilea = titluDeCalatorieMetropolitan.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");
        assertTrue("primul equals alDoilea", primul.equals(alDoilea));
    }

    @Test
    public void testeazaClone() {
        try {
            Object primul = titluDeCalatorieMetropolitan.getConstructor(String.class, int.class, String.class, String.class, float.class, String.class).
                    newInstance("denumire", 1, "20180504231634", "20180505231634", 3.0f, "denumire-operator");

            Method cloneMethod = titluDeCalatorieMetropolitan.getMethod("clone");

            Object clona = cloneMethod.invoke(primul);

            Method setDenumire = titluDeCalatorieMetropolitan.getMethod("setDenumireOperatorMetropolitan", String.class);
            Method getDenumire = titluDeCalatorieMetropolitan.getMethod("getDenumireOperatorMetropolitan");

            setDenumire.invoke(clona, "test clone");

            assertEquals("testeaza denumire operator primul", "denumire-operator", getDenumire.invoke(primul));
            assertEquals("testeaza denumire operator clona", "test clone", getDenumire.invoke(clona));
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
