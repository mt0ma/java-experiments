package eu.ase;

public class PasagerEc extends Pasager implements Cloneable {
	private String nrCardEc;

	public PasagerEc(String nume, float numarLoc, float varsta, String nrCardEc) throws Exception  {
		super(nume, numarLoc, varsta);
		if (numarLoc < 0)
			throw new Exception();
		this.nrCardEc = nrCardEc;
	}
	
	public void setNrCardEc(String nrCardEc) {
		this.nrCardEc = nrCardEc;
	}
	public String getNrCardEc() {
		return this.nrCardEc;
	}

	@Override
	public String getIdRezervareAbs() {
		String concatenare=null;
		concatenare = this.getIdRezervare() + this.nrCardEc;
		return concatenare;
	}

	@Override
    public Object clone() throws CloneNotSupportedException {
		//super.clone(); //ar fi fost eroare la executie daca clasa mea nu declara "implements Clonable"
		PasagerEc newOb = (PasagerEc) super.clone(); 
		if (this.nrCardEc != null) 
			newOb.nrCardEc = new String("" + this.nrCardEc);

		return newOb;
    }

	@Override
	public boolean equals(Object o) {
        if (!(o instanceof PasagerEc))
            return false;
        PasagerEc p = (PasagerEc) o;
        
        return (p.getNume().compareTo(this.getNume()) == 0) &&
               (p.getNumarLoc() == this.getNumarLoc()) &&
               (p.getVarsta() == this.getVarsta()) &&
               (p.nrCardEc.compareTo(this.nrCardEc) == 0);
    }
}
