package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Method;
import java.util.Arrays;

import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.*;

public class TesteazaMatrice {
    static Class matrice;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            matrice = setup.loadClassFromProjectPath(projectPath, "eu.ase.Matrice");
        } catch (Exception e) {
            System.out.println("Could not load Matrice " + e.getMessage());
        }
    }

    @Test
    public void testeazaClone() throws Exception{
        try {
            Object[][] oMatriceValue = new Object[][]{{1, 2}, {3, 4}};
            Object oMatrice = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, oMatriceValue);


            Method cloneaza = matrice.getMethod("clone");
            Object oClona = cloneaza.invoke(oMatrice);

            Method getMatrice = matrice.getMethod("getMatrice");
            Method setMatrice = matrice.getMethod("setMatrice", Object[][].class);

            Object[][] newValue = new Object[][]{{111, 222}, {333, 444}};
            Object[] params = {newValue}; // invoke expects (objectToInvokeFor, Object...params so Object[])
            setMatrice.invoke(oClona, params);

            assertTrue("testeaza oMatrice", this.matricesEquals(new Object[][]{{1, 2}, {3, 4}}, (Object[][])getMatrice.invoke(oMatrice)));
            assertTrue("testeaza oClona", this.matricesEquals(new Object[][]{{111, 222}, {333, 444}}, (Object[][])getMatrice.invoke(oClona)));

        } catch (Exception e) {
            throw new Exception(e);
        }
    }

    private boolean matricesEquals(Object[][] matrix1, Object[][] matrix2) {
        if(matrix1 == matrix2) {
            return true;
        }
        if((matrix1 == null && matrix2 != null) ||
                (matrix1 != null && matrix2 == null) ||
                (matrix1.length != matrix2.length)) {
            return false;
        }
        for(int i = 0; i < matrix1.length; i++) {
            if(!Arrays.equals(matrix1[i], matrix2[i])) {
                return false;
            }
        }
        return true;
    }

    @Test
    public void testeazaEquals() {
        try {
            Object prima = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, new Object[][]{{1, 2}, {3, 4}});

            Object aceeasi = prima;
            assertTrue("testeaza equals de referinta", prima.equals(aceeasi));

            Object unaNull = null;
            assertFalse("testeaza equals de null", prima.equals(unaNull));

            Object altfelDeObiect = new String("altfel de obiect");
            assertFalse("testeaza equals de tip", prima.equals(altfelDeObiect));

            Object aDoua = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, new Object[][]{{1, 2}, {3, 4}});
            assertTrue("prima equals aDoua", prima.equals(aDoua));

            Object aTreia = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(3, 1, new Object[][]{{1, 2}, {3, 4}});
            assertFalse("testeaza dimensiuni diferite", prima.equals(aTreia));
        } catch(Exception e) {
            fail(e.getMessage());
        }

    }

    @Test
    public void testeazaGetNullsNumber() {
        try {
            Method getNullsNumber = matrice.getMethod("getNullsNumber");

            Object matrice1 = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, new Object[][]{{null, null}, {null, null}});
            assertEquals("toate elementele null ", 4, getNullsNumber.invoke(matrice1));

            Object matrice2 = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, new Object[][]{{-1, 2}, {-3, 4}});
            assertEquals("toate elementele diferite de null ", 0, getNullsNumber.invoke(matrice2));

            Object matrice3 = matrice.getConstructor(int.class, int.class, Object[][].class).
                    newInstance(2, 2, new Object[][]{{1, null}, {null, -1}});
            assertEquals("o parte din elemente diferite de null ", 2, getNullsNumber.invoke(matrice3));

        } catch (NoSuchMethodException nsme) {
            fail("Metoda getNullsNumber nu este definita");
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
