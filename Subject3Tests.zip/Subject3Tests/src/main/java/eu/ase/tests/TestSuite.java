package eu.ase.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        TesteazaSintacticClasaPasager.class,
        TesteazaPasagerEc.class,
        TesteazaPasagerVIP.class,
        TesteazaMatrice.class
})
/*
 * Suita teste pentru nota 5
 */
public class TestSuite {
}
