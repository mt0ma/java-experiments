package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;

/**
 * Testeaza PasagerEc
 */
public class TesteazaPasagerEc {
    static Class pasagerEc;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            pasagerEc = setup.loadClassFromProjectPath(projectPath, "eu.ase.PasagerEc");
        } catch (Exception e) {
            System.out.println("Could not load PasagerEc " + e.getMessage());
        }
    }

    @Test
    public void testeazaAtributulNrCardEc() {
        try {
            Field nrCardEc = pasagerEc.getDeclaredField("nrCardEc");
            assertNotNull(nrCardEc);
            assertTrue("Atributul 'nrCardEc' este privat",  Modifier.isPrivate(nrCardEc.getModifiers()));
            assertEquals("Atributul 'nrCardEc' este de tip String", String.class, nrCardEc.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'nrCardEc' nu exista in clasa " + pasagerEc);
        }
    }

    @Test
    public void testeazaMetodeDeAccesPentruCampulDenumireOperatorMetropolitan() {
        try {
            Method metodaAccesGetNrCardEc = pasagerEc.getMethod("getNrCardEc");
            Method metodaAccesSetNrCardEc = pasagerEc.getMethod("setNrCardEc", String.class);

            assertTrue("Metoda de acces metodaAccesGetNrCardEc este publica", Modifier.isPublic(metodaAccesGetNrCardEc.getModifiers()));
            assertEquals("Metoda get metodaAccesGetNrCardEc intoarce String", String.class, metodaAccesGetNrCardEc.getReturnType());

            assertTrue("Metoda de acces metodaAccesSetNrCardEc este publica", Modifier.isPublic(metodaAccesSetNrCardEc.getModifiers()));
            assertEquals("Metoda get metodaAccesSetNrCardEc are un parametru", 1, metodaAccesSetNrCardEc.getParameterCount());
            assertEquals("Metoda get metodaAccesSetNrCardEc intoarce void", void.class, metodaAccesSetNrCardEc.getReturnType());

        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getNrCardEc() sau setNrCardEc() nu este definita");
        }
    }

    @Test(expected = Exception.class)
    public void testeazaConstructorGenereazaExceptie() throws Exception{
        Object pasagerEconomic = pasagerEc.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", -1.0, 20.0f, "20180505231634");
    }

    @Test
    public void testeazaGetIdRezervareAbs() throws Exception {
        Object pasager = pasagerEc.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("ionica", 1.0f, 3.0f, "435237127");
        Method getIdRezervareAbs = pasagerEc.getMethod("getIdRezervareAbs");
        assertEquals("getIdRezervareAbs() intoarce id rezervare concatenat cu nr card",
                new String(1 + "435237127"),
                getIdRezervareAbs.invoke(pasager));
    }

    @Test
    public void testeazaEquals() throws Exception{
        Object primul = pasagerEc.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", 1.0f, 20.0f, "20180505231634");

        Object acelasi = primul;
        assertTrue("testeaza equals de referinta", primul.equals(acelasi));

        Object unulNull = null;
        assertFalse("testeaza equals de null", primul.equals(unulNull));

        Object altfelDeObiect = new String("denumire");
        assertFalse("testeaza equals de tip", primul.equals(altfelDeObiect));

        Object alDoilea = pasagerEc.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", 1.0f, 20.0f, "20180505231634");
        assertTrue("primul equals alDoilea", primul.equals(alDoilea));
    }

    @Test
    public void testeazaClone() {
        try {
            Object primul = pasagerEc.getConstructor(String.class, float.class, float.class, String.class).
                    newInstance("gigel", 1.0f, 20.0f, "111111");

            Method cloneMethod = pasagerEc.getMethod("clone");

            Object clona = cloneMethod.invoke(primul);

            Method setNrCardEc = pasagerEc.getMethod("setNrCardEc", String.class);
            Method getNrCardEc = pasagerEc.getMethod("getNrCardEc");

            setNrCardEc.invoke(clona, "222222");

            assertEquals("testeaza nr card primul", "111111", getNrCardEc.invoke(primul));
            assertEquals("testeaza nr card clona", "222222", getNrCardEc.invoke(clona));
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
