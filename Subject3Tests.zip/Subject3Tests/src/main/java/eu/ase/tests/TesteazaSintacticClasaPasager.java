package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Teste ce corespund punctajului 3
 */

public class TesteazaSintacticClasaPasager {

    static Class pasagerClass;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            pasagerClass = setup.loadClassFromProjectPath(projectPath, "eu.ase.Pasager");
        } catch (Exception e) {
            System.out.println("Could not load Pasager " + e.getMessage());
        }
    }

    @Test
    public void testeazaPasagerEsteClasaAbstracta() {
        assertTrue(Modifier.isAbstract(pasagerClass.getModifiers()));
    }


    @Test
    public void testeazaAtributulNume() {
        try {
            Field atributNume = pasagerClass.getDeclaredField("nume");
            assertNotNull(atributNume);
            assertTrue("Atributul 'nume' este privat",  Modifier.isPrivate(atributNume.getModifiers()));
            assertEquals("Atributul 'nume' este de tip String ", String.class, atributNume.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'nume' nu exista in clasa " + pasagerClass);
        }
    }

    @Test
    public void testeazaAtributulNumarLoc() {
        try {
            Field atributNumarLoc = pasagerClass.getDeclaredField("numarLoc");
            assertNotNull(atributNumarLoc);
            assertTrue("Atributul 'numarLoc' este privat",  Modifier.isPrivate(atributNumarLoc.getModifiers()));
            assertEquals("Atributul 'numarLoc' este de tip float", float.class, atributNumarLoc.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'numarLoc' nu exista in clasa " + pasagerClass);
        }
    }

    @Test
    public void testeazaAtributulVarsta() {
        try {
            Field atributVarsta = pasagerClass.getDeclaredField("varsta");
            assertNotNull(atributVarsta);
            assertTrue("Atributul 'varsta' este privat",  Modifier.isPrivate(atributVarsta.getModifiers()));
            assertEquals("Atributul 'varsta' este de tip float", float.class, atributVarsta.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'varsta' nu exista in clasa " + pasagerClass);
        }
    }


    @Test
    public void testeazaAtributulIdRezervare() {
        try {
            Field atributIdRezervare = pasagerClass.getDeclaredField("idRezervare");
            assertNotNull(atributIdRezervare);
            assertTrue("Atributul 'idRezervare' este privat",  Modifier.isPrivate(atributIdRezervare.getModifiers()));
            assertTrue("Atributul 'idRezervare' este final",  Modifier.isFinal(atributIdRezervare.getModifiers()));
            assertEquals("Atributul 'idRezervare' este de tip int", int.class, atributIdRezervare.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'idRezervare' nu exista in clasa " + pasagerClass);
        }
    }

    @Test
    public void testeazaConstructorAlClaseiPasager() {
        Constructor[] constructori = pasagerClass.getConstructors();
        assertEquals("Exista un singur constructor definit in clasa " + pasagerClass, 1, constructori.length);

        Constructor constructorDeclarat = constructori[0];
        assertEquals("Exista trei parametri definiti pentru constructorul clasei " + pasagerClass, 3, constructorDeclarat.getParameterCount());

        Class[] tipuriParametri = constructorDeclarat.getParameterTypes();

        int numarParametriString = 0;
        int numarParametriFloat = 0;
        for(int i=0; i< tipuriParametri.length; i++) {
            numarParametriString = tipuriParametri[i].equals(String.class) ? numarParametriString + 1 : numarParametriString;
            numarParametriFloat = tipuriParametri[i].equals(float.class) ? numarParametriFloat + 1 : numarParametriFloat;
        }

        assertEquals("Exista trei parametri String ", 1, numarParametriString);
        assertEquals("Exista un parametru float ", 2, numarParametriFloat);
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulNume() {
        try {
            Method metodaAccesNume = pasagerClass.getMethod("getNume");
            assertTrue("Metoda de acces nume este publica", Modifier.isPublic(metodaAccesNume.getModifiers()));
            assertEquals("Metoda get nume intoarce String", String.class, metodaAccesNume.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getNume() nu este definita");
        }
    }


    @Test
    public void testeazaMetodaDeAccesPentruCampulNumarLoc() {
        try {
            Method metodaAccesNumarLoc = pasagerClass.getMethod("getNumarLoc");
            assertTrue("Metoda de acces numarLoc este publica", Modifier.isPublic(metodaAccesNumarLoc.getModifiers()));
            assertEquals("Metoda get numarLoc intoarce float", float.class, metodaAccesNumarLoc.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getIdLinie() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaDeAccesPentruCampulVarsta() {
        try {
            Method metodaAccesVarsta = pasagerClass.getMethod("getVarsta");
            assertTrue("Metoda de acces varsta este publica", Modifier.isPublic(metodaAccesVarsta.getModifiers()));
            assertEquals("Metoda get varsta intoarce float", float.class, metodaAccesVarsta.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getVarsta() nu este definita");
        }
    }

    @Test
    public void testeazaMetodaAbstractaGetIdRezervare() {
        try {
            Method metodaGetIdRezervare = pasagerClass.getMethod("getIdRezervareAbs");
            assertTrue("Metoda getIdRezervareAbs este publica", Modifier.isPublic(metodaGetIdRezervare.getModifiers()));
            assertTrue("Metoda getIdRezervareAbs este abstracta", Modifier.isAbstract(metodaGetIdRezervare.getModifiers()));
            assertEquals("Metoda getIdRezervareAbs intoarce String", String.class, metodaGetIdRezervare.getReturnType());
        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getIdRezervareAbs() nu este definita");
        }
    }


}
