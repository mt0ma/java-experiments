package eu.ase.tests;

import eu.ase.setup.TestSetup;
import org.junit.BeforeClass;
import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;

/**
 * Testeaza PasagerVIP
 */
public class TesteazaPasagerVIP {
    static Class pasagerVIP;

    @BeforeClass
    public static void setUp() {
        String projectPath = System.getProperty("projectPath");
        TestSetup setup = new TestSetup();
        try {
            pasagerVIP = setup.loadClassFromProjectPath(projectPath, "eu.ase.PasagerVIP");
        } catch (Exception e) {
            System.out.println("Could not load PasagerVIP " + e.getMessage());
        }
    }

    @Test
    public void testeazaAtributulNrCardVIP() {
        try {
            Field nrCardVIP = pasagerVIP.getDeclaredField("nrCardVIP");
            assertNotNull(nrCardVIP);
            assertTrue("Atributul 'nrCardVIP' este privat",  Modifier.isPrivate(nrCardVIP.getModifiers()));
            assertEquals("Atributul 'nrCardVIP' este de tip String", String.class, nrCardVIP.getType());
        } catch (NoSuchFieldException nsfe) {
            fail("Atributul 'nrCardVIP' nu exista in clasa " + pasagerVIP);
        }
    }

    @Test
    public void testeazaMetodeDeAccesPentruCampulDenumireOperatorMetropolitan() {
        try {
            Method getNrCardVIP = pasagerVIP.getMethod("getNrCardVIP");
            Method setNrCardVIP = pasagerVIP.getMethod("setNrCardVIP", String.class);

            assertTrue("Metoda de acces getNrCardVIP este publica", Modifier.isPublic(getNrCardVIP.getModifiers()));
            assertEquals("Metoda get getNrCardVIP intoarce String", String.class, getNrCardVIP.getReturnType());

            assertTrue("Metoda de acces setNrCardVIP este publica", Modifier.isPublic(setNrCardVIP.getModifiers()));
            assertEquals("Metoda get setNrCardVIP are un parametru", 1, setNrCardVIP.getParameterCount());
            assertEquals("Metoda get setNrCardVIP intoarce void", void.class, setNrCardVIP.getReturnType());

        } catch(NoSuchMethodException nsme) {
            fail("Metoda de acces getNrCardVIP() sau setNrCardVIP() nu este definita");
        }
    }

    @Test(expected = Exception.class)
    public void testeazaConstructorGenereazaExceptie() throws Exception{
        Object pasager = pasagerVIP.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", -1.0, 20.0f, "20180505231634");
    }

    @Test
    public void testeazaGetIdRezervareAbs() throws Exception {
        Object pasager = pasagerVIP.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("ionica", 1.0f, 3.0f, "435237127");
        Method getIdRezervareAbs = pasagerVIP.getMethod("getIdRezervareAbs");
        assertEquals("getIdRezervareAbs() intoarce id rezervare concatenat cu nr card",
                new String(1 + "435237127"),
                getIdRezervareAbs.invoke(pasager));
    }

    @Test
    public void testeazaEquals() throws Exception{
        Object primul = pasagerVIP.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", 1.0f, 20.0f, "20180505231634");

        Object acelasi = primul;
        assertTrue("testeaza equals de referinta", primul.equals(acelasi));

        Object unulNull = null;
        assertFalse("testeaza equals de null", primul.equals(unulNull));

        Object altfelDeObiect = new String("denumire");
        assertFalse("testeaza equals de tip", primul.equals(altfelDeObiect));

        Object alDoilea = pasagerVIP.getConstructor(String.class, float.class, float.class, String.class).
                newInstance("gigel", 1.0f, 20.0f, "20180505231634");
        assertTrue("primul equals alDoilea", primul.equals(alDoilea));
    }

    @Test
    public void testeazaClone() {
        try {
            Object primul = pasagerVIP.getConstructor(String.class, float.class, float.class, String.class).
                    newInstance("gigel", 1.0f, 20.0f, "111111");

            Method cloneMethod = pasagerVIP.getMethod("clone");

            Object clona = cloneMethod.invoke(primul);

            Method setNrCardVIP = pasagerVIP.getMethod("setNrCardVIP", String.class);
            Method getNrCardVIP = pasagerVIP.getMethod("getNrCardVIP");

            setNrCardVIP.invoke(clona, "222222");

            assertEquals("testeaza nr card primul", "111111", getNrCardVIP.invoke(primul));
            assertEquals("testeaza nr card clona", "222222", getNrCardVIP.invoke(clona));
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
