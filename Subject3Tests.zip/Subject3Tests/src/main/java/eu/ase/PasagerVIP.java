package eu.ase;

public class PasagerVIP extends Pasager implements Cloneable {
	private String nrCardVIP;

	public PasagerVIP(String nume, float numarLoc, float varsta, String nrCardVIP) throws Exception  {
		super(nume, numarLoc, varsta);
		if (numarLoc < 0)
			throw new Exception();
		this.nrCardVIP = nrCardVIP;
	}
	
	public void setNrCardVIP(String nrCardVIP) {
		this.nrCardVIP = nrCardVIP;
	}
	public String getNrCardVIP() { return this.nrCardVIP; }

	@Override
	public String getIdRezervareAbs() {
		String concatenare=null;
		concatenare = this.getIdRezervare() + this.nrCardVIP;
		return concatenare;
	}

	@Override
    public Object clone() throws CloneNotSupportedException {
		//super.clone(); //ar fi fost eroare la executie daca clasa mea nu declara "implements Clonable"
		PasagerVIP newOb = (PasagerVIP) super.clone(); 
		if (this.nrCardVIP != null) newOb.nrCardVIP = new String("" + this.nrCardVIP);

		return newOb;
    }

	@Override
	public boolean equals(Object o) {
        if (!(o instanceof PasagerVIP))
            return false;
        PasagerVIP p = (PasagerVIP) o;
        
        return (p.getNume().compareTo(this.getNume()) == 0) &&
               (p.getNumarLoc() == this.getNumarLoc()) &&
               (p.getVarsta() == this.getVarsta()) &&
               (p.nrCardVIP.compareTo(this.nrCardVIP) == 0);
    }
}
	
