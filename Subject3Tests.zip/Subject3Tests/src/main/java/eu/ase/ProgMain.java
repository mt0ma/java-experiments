package eu.ase;

public class ProgMain {

	public static void main(String[] args) {
		PasagerVIP pv1, pv2, pv3;
		try {
			pv1 = new PasagerVIP("Popescu", 12, 20, "B123");
			pv2 = new PasagerVIP("Popescu", 13, 21, "B124");
			pv3 = new PasagerVIP("Popescu", 13, 21, "B124");
			if (pv1.equals(pv2))
				System.out.println("incorrect true");
			else
				System.out.println("correct false");
			
			if (pv2.equals(pv3))
				System.out.println("correct true");
			else
				System.out.println("incorrect false");
			
			Pasager[][] objs = new Pasager[][]{{pv1, pv2}, {null, pv3}};
			Matrice m = new Matrice(2, 2, (Object[][])objs);
			System.out.println("nn = " + m.getNullsNumber());
		} catch (Exception e) {
			e.printStackTrace();
		}
	    
	}

}
