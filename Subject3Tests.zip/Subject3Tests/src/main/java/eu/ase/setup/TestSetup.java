package eu.ase.setup;

import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public class TestSetup {

    public TestSetup() {}

    public Class loadClassFromProjectPath(String projectPath, String className) throws Exception {
        ClassLoader testClassLoader = new TestClassLoader();

        URL url = this.getClass().getResource(projectPath);
        URLClassLoader urlClassLoader = (URLClassLoader) ClassLoader
        .getSystemClassLoader();

        Class<?> urlClass = URLClassLoader.class;
        Method method = urlClass.getDeclaredMethod("addURL", new Class[] { URL.class });
        method.setAccessible(true);
        method.invoke(urlClassLoader, new Object[] { url });

        return Class.forName(className, true, urlClassLoader);
    }

    class TestClassLoader extends URLClassLoader {
        public TestClassLoader() {
            super(((URLClassLoader) getSystemClassLoader()).getURLs());
        }

        @Override
        public Class<?> loadClass(String name) throws ClassNotFoundException {
            if (name.startsWith("eu.ase")) {
                return super.findClass(name);
            }

            return super.loadClass(name);
        }
    }
}

