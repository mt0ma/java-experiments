package eu.ase;

public class Matrice implements Cloneable {
	private int nrLinii;
	private int nrColoane;
	private Object[][] matrice;
	//constructor default
	public Matrice() {	
	}
	
	//constructor cu parametri
	public Matrice(int nrLinii, int nrColoane, Object[][] matrice) {
		this.nrLinii = nrLinii;
		this.nrColoane = nrColoane;
		this.matrice = matrice;
	}
	
	//get si set
	public int getNrLinii() {
		return nrLinii;
	}
	
	public void setNrLinii(int nrLinii) {
		this.nrLinii = nrLinii;
	}
	
	public int getNrColoane() {
		return nrColoane;
	}
	
	public void setNrColoane(int nrColoane) {
		this.nrColoane = nrColoane;
	}
	
	public Object[][] getMatrice() {
		return matrice;
	}
	
	public void setMatrice(Object[][] matrice) {
		this.matrice = matrice;
	}
	
	@Override
    public Object clone() throws CloneNotSupportedException {
		//super.clone(); //ar fi fost eroare la executie daca clasa mea nu declara "implements Clonable"
		Matrice newOb = (Matrice) super.clone(); 
		newOb.nrLinii = this.nrLinii;
		newOb.nrColoane = this.nrColoane;
		
		if (this.matrice != null) {
			newOb.matrice = new Object[this.nrLinii][this.nrColoane];
			for (int i = 0; i < this.nrLinii; i++) {
				for (int j = 0; j < this.nrColoane; j++) {
					newOb.matrice[i][j] = this.matrice[i][j]; 
				}
			}
		}
		
		return newOb;
    }
	
	@Override
	public boolean equals(Object o) {
        if (!(o instanceof Matrice))
            return false;
        Matrice m = (Matrice) o;
        
        boolean result = (m.nrLinii == this.nrLinii) && 
        		(m.nrColoane == this.nrColoane);
        
        for (int i = 0; i < this.nrLinii; i++) {
			for (int j = 0; j < this.nrColoane; j++) {
				if (m.matrice[i][j] != this.matrice[i][j]) {
					result = false;
					return result;
				}
			}
		}
        
        return result;
        
    }
	
	public int getNullsNumber() {
		int r = 0;
		for (int i = 0; i < this.nrLinii; i++) {
			for (int j = 0; j < this.nrColoane; j++) {
				if (this.matrice[i][j] == null) {
					r++;
				}
			}
		}
		return r;
	}
}
