package eu.ase;

import java.util.Objects;

public class TitluCalatorieMetropolitan extends TitluCalatorie implements Cloneable {
    private String denumireOperatorMetropolitan;

	public TitluCalatorieMetropolitan(String denumire,
									  int id,
									  String dataStart,
									  String dataStop,
									  float idLinie,
									  String denumireOperator) throws Exception{
		super(id, denumire, idLinie, dataStart, dataStop);
		if(idLinie < 0) {
			throw new Exception("idLinie negativ");
		}
		this.denumireOperatorMetropolitan = denumireOperator;
	}

	@Override
	public String getIdZona() {
		return (this.getIdLinie()+""+this.denumireOperatorMetropolitan);
	}

	public String getDenumireOperatorMetropolitan(){
		return this.denumireOperatorMetropolitan;
	}

	public void setDenumireOperatorMetropolitan(String denumire) {
		this.denumireOperatorMetropolitan = denumire;
	}

	@Override
	public TitluCalatorieMetropolitan clone() throws CloneNotSupportedException {
		TitluCalatorieMetropolitan clona = (TitluCalatorieMetropolitan)super.clone();
		clona.denumireOperatorMetropolitan = new String(this.denumireOperatorMetropolitan);
		return clona;
	}

	@Override
	public boolean equals(Object obj){
		if(this == obj) {
			return true;
		}
		if(obj == null) {
			return false;
		}
		if(this.getClass() != obj.getClass()) {
			return false;
		}

		TitluCalatorieMetropolitan other = (TitluCalatorieMetropolitan)obj;

		/*if((other.denumireOperatorMetropolitan == null && this.denumireOperatorMetropolitan != null) ||
				(other.denumireOperatorMetropolitan != null && this.denumireOperatorMetropolitan == null) ||
				(!other.denumireOperatorMetropolitan.equals(this.denumireOperatorMetropolitan))) {
			return false;
		} */
		if(!Objects.equals(other.denumireOperatorMetropolitan, this.denumireOperatorMetropolitan)) {
			return false;
		}

		return true;
	}
}
