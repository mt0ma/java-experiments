package eu.ase;


public abstract class TitluCalatorie {
    private int id;
    private String denumire;
    private float idLinie;
    private String dataStart;
    private String dataStop;
    private final int idZona = 1;

    public TitluCalatorie(int id, String denumire, float idLinie, String dataStart, String dataStop) {
        this.id = id;
        this.denumire = denumire;
        this.idLinie = idLinie;
        this.dataStart = dataStart;
        this.dataStop = dataStop;
    }

    public int getId() {
        return id;
    }

    public String getDenumire() {
        return denumire;
    }

    public float getIdLinie() {
        return idLinie;
    }

    public String getDataStart() {
        return dataStart;
    }

    public String getDataStop() {
        return dataStop;
    }

    public abstract String getIdZona();

    @Override
    public Object clone() throws CloneNotSupportedException {
        TitluCalatorie clona = (TitluCalatorie)super.clone();
        clona.id = this.id;
        clona.denumire = new String(this.denumire);
        clona.idLinie = this.idLinie;
        clona.dataStart = new String(this.dataStart);
        clona.dataStop = new String(this.dataStop);
        return clona;
    }
}
