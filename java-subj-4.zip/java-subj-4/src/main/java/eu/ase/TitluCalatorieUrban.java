package eu.ase;

import java.util.Objects;

public class TitluCalatorieUrban extends TitluCalatorie implements Cloneable{
    private String denumireOperatorUrban;

	public TitluCalatorieUrban(String denumire,
                               int id,
                               String dataStart,
                               String dataStop,
                               float idLinie,
                               String denumireOperator) throws Exception{
		super(id, denumire, idLinie, dataStart, dataStop);
		if(idLinie < 0) {
			throw new Exception("idLinie negativ");
		}
		this.denumireOperatorUrban = denumireOperator;
	}

	@Override
	public String getIdZona() {
		return (this.getIdLinie()+""+this.denumireOperatorUrban);
	}

	public String getDenumireOperatorUrban(){
		return this.denumireOperatorUrban;
	}

	public void setDenumireOperatorUrban(String denumire){
		this.denumireOperatorUrban = denumire;
	}

	@Override
	public TitluCalatorieUrban clone() throws CloneNotSupportedException {
		TitluCalatorieUrban clona = (TitluCalatorieUrban)super.clone();
		clona.denumireOperatorUrban = new String(this.denumireOperatorUrban);
		return clona;
	}

	@Override
	public boolean equals(Object obj){
		if(this == obj) {
			return true;
		}
		if(obj == null) {
			return false;
		}
		if(this.getClass() != obj.getClass()) {
			return false;
		}

		TitluCalatorieUrban other = (TitluCalatorieUrban)obj;

		/*if((other.denumireOperatorMetropolitan == null && this.denumireOperatorMetropolitan != null) ||
				(other.denumireOperatorMetropolitan != null && this.denumireOperatorMetropolitan == null) ||
				(!other.denumireOperatorMetropolitan.equals(this.denumireOperatorMetropolitan))) {
			return false;
		} */
		if(!Objects.equals(other.denumireOperatorUrban, this.denumireOperatorUrban)) {
			return false;
		}

		return true;
	}
}
